# tests/test_lista.py

from src.exercicio1_lista import adicionar_numero, remover_numero, buscar_numero

def test_adicionar_numero():
    lista = []
    resultado = adicionar_numero(lista, 5)
    assert resultado == [5]
    resultado = adicionar_numero(lista, 10)
    assert resultado == [5, 10]

def test_remover_numero():
    lista = [5, 10, 15]
    resultado = remover_numero(lista, 10)
    assert resultado == [5, 15]
    resultado = remover_numero(lista, 20)  # Testando remoção de número não existente
    assert resultado == [5, 15]

def test_buscar_numero():
    lista = [5, 10, 15]
    assert buscar_numero(lista, 10) is True
    assert buscar_numero(lista, 20) is False
