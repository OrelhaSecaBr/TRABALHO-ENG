# src/exercicio1_lista.py

def adicionar_numero(lista, numero):
    """Adiciona um número à lista."""
    lista.append(numero)
    return lista

def remover_numero(lista, numero):
    """Remove um número da lista, se ele existir."""
    if numero in lista:
        lista.remove(numero)
    return lista

def buscar_numero(lista, numero):
    """Verifica se o número está na lista."""
    return numero in lista
