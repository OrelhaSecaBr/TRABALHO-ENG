TRABALHO FEITO POR : HENRIQUE ALBARNAS E JOÃO G. COELHO
2° INFO-A

| Cenário  | Passos | Resultado Esperado | Resultado observado | Status |
| ------------- | ------------- |  ------------- |  ------------- |  ------------- |
| Adicionar um número à lista(vazia)  | Preencher "5" e enviar | Retornar "5" | Retornou "5" | ✔ |
| Adiconar um número à lista "5" | Preencher "10" e enviar | Retornar "5, 10" | Retornou "5, 10" | ✔ |
| Remover um número existente da lista "5, 10, 15"  | Preemcher "10" e enviar  | Lista retorne "5, 15" | Retornou "5, 15" | ✔ |
| Remover um número inexistente da lista "5, 10, 15" | Preencher "20" e enviar| Lista retorne "5, 15" | Retornou "5, 15" | ✔ |
| Buscar um número existente da lista "5, 10, 15" | Preencher "10" e enviar | Retorne "10" | Retornou "10" | ✔ |
| Buscar um número inexistente da lista "5, 10, 15" | Preencher "20" e enviar | Retorne "False" | Retornou "False" | ✔ |
